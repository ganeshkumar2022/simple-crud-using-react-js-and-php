import 'bootstrap/dist/css/bootstrap.css';
import './App.css';
import React, { useState,useEffect } from 'react';
import axios from 'axios';

function App() {

  const [items, setItems] = useState([]);
  const [newitem, setNewItem] = useState('');
  const [editItem, setEditItem] = useState('');
  const [editingId, setEditingId] = useState(null);

  useEffect(()=>{
    fetch("http://localhost/practice/react_backend.php")
    .then((response)=>{
      return response.json();
    })
    .then((data)=>{
      console.log(data);
      setItems(data);
    }).catch(err=>{
      console.log(err);
    })

  },[]);

  const AddItem = async () => {
    if (newitem.trim()) {
      const uid=Math.floor(Math.random() * (99999999 - 1 + 1)) + 1;
      const item = {
        id: uid,
        name: newitem
      };

      //add data start
      const url="http://localhost/practice/react_backend.php";
      try
      {
        const response=await axios.post(url,item);
        alert(response.data.message);
        setItems([...items, item]);
      }
      catch(error)
      {
        console.log(error);
      }
      
      //add data end

      setNewItem('');
    }
  }

  const handleSaveEdit = async() => {
    

    //update data start
    const url="http://localhost/practice/react_backend.php";
    try
    {
      const response=await axios.put(url,{
        id:editingId,
        name:editItem
      });
      alert(response.data.message);

      if (editItem.trim()) {
        setItems(items.map(item => item.id === editingId ? { ...items, id: item.id, name: editItem } : item));
      }

    }
    catch(error)
    {
      console.log(error);
    }
          
    //update data end

    setEditItem('');
    setEditingId(null);
  }

  const handleEditItem = (id) => {
    const itemToEdit = items.find(item => item.id === id);
    setEditItem(itemToEdit.name);
    setEditingId(id);
  }

  const handleDeleteItem = async(id) => {

     //delete data start
     const url="http://localhost/practice/react_backend.php?id="+id;
     try
     {
       const response=await axios.delete(url);
       alert(response.data.message);
       
        setItems(items.filter(item => item.id !== id));
       
     }
     catch(error)
     {
       console.log(error);
     }
           
     //delete data end
  }

  return (
    <>
    <header>
      <div className="bg-dark">
        <h3 className='text-white py-3 text-center'>Crud Operation Using React JS</h3>
      </div>
    </header>
      <div className="container">
      {editingId == null &&
        <div className='row'>
          <div className='col-md-6 offset-3'>
            <div className='card my-2'>
              <div className='card-body'>
                <h3 className='text-center text-primary'>Add Data</h3>
                <label>Enter name :</label>
                <input type="text" placeholder='Ente Name' className='form-control' value={newitem} onChange={(e) => setNewItem(e.target.value)} />
                <button onClick={AddItem} className='btn btn-primary mt-2'>Add User</button>
              </div>
            </div>
          </div>
        </div> }
        {editingId !== null &&
          <div>
            <div className='row'>
            <div className='col-md-6 offset-3'>
            <div className='card my-2'>
            <div className='card-body'>
            <h3 className='text-center text-primary'>Edit Data</h3>
            <label>Enter name :</label>
            <input type="text" placeholder='edit Item' className='form-control' value={editItem} onChange={(e) => setEditItem(e.target.value)} />
            <button onClick={handleSaveEdit} className='btn btn-primary mt-2'>Edit User</button>
          </div></div></div></div></div>}
        <h3 className='text-center text-white'>All Datas</h3>
        <table className='table table-bordered'>
          <thead className='table-primary'>
            <tr>
              <th>S.No</th>
              <th>Name</th>
              <th>Manage</th>
            </tr>
          </thead>
          <tbody>
            {items.map((item,index) => (
              <tr key={item.id}>
                <td>{index+1}</td>
                <td>{item.name}</td>
                <td>
                  <button onClick={() => handleEditItem(item.id)} className='btn btn-success'>Edit</button>
                  <button onClick={() => handleDeleteItem(item.id)} className='ms-2 btn btn-danger'>Delete</button>
                </td>
              </tr>
            ))}
            {items.length==0 ? 
            <tr key='0'>
            <td colSpan="3" align='center'>
              No records found
            </td>
          </tr>
          
          : ''
            }
          </tbody>
        </table>
        <ul>

        </ul>

      </div>
    </>
  )
}

export default App;
