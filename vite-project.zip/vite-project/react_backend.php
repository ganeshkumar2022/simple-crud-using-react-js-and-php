<?php

// Set headers for CORS (Cross-Origin Resource Sharing)
header('Access-Control-Allow-Origin: *'); // Allow requests from all origins
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE'); // Allow specific HTTP methods
header('Access-Control-Allow-Headers: Content-Type, Authorization'); // Allow headers for requests
header("Content-type:application/json");


//db connect
$servername="localhost";
$username="root";
$password="";
$dbname="practice";
$str="mysql:host=$servername;dbname=$dbname";
try
{
    $con=new PDO($str,$username,$password);
    
}
catch(PDOException $e)
{
    echo "Error :".$e->getMessage();
}
//db connect


//get all data start
if($_SERVER['REQUEST_METHOD']=="GET")
{
    $sql="select * from react_user";
    $result=$con->query($sql);
    $result->execute();
    $a=$result->fetchAll(PDO::FETCH_ASSOC);
/*$a=[
['id'=>1,'name'=>'ganesh'],
['id'=>2,'name'=>'priya'],
];*/
echo json_encode($a);
}
//get all data end

//insert data start
if($_SERVER['REQUEST_METHOD']=="POST")
{
    $data=file_get_contents("php://input");
    $data=json_decode($data,true);
    $id=$data['id'];
    $name=$data['name'];

    if(empty($name))
    {
        echo json_encode(array("message"=>"Please enter Name"));
        exit;
    }

    $sql="insert into react_user (id,name) value (:id,:name)";
    $result=$con->prepare($sql);
    $result->bindParam(":id",$id);
    $result->bindParam(":name",$name);
    
    try
    {
        $result->execute();
        echo json_encode(array("message"=>"Data stored"));
        exit;
    }
    catch(Exception $e)
    {
        echo json_encode(array("message"=>"Error to Insert"));
        exit;
    }

    

}
//insert data end

//update data start
if($_SERVER['REQUEST_METHOD']=="PUT")
{
    $data=file_get_contents("php://input");
    $data=json_decode($data,true);
    $id=$data['id'];
    $name=$data['name'];

    if(empty($name))
    {
        echo json_encode(array("message"=>"Please enter Name"));
        exit;
    }

    $sql="update react_user set name=:name where id=:id";
    $result=$con->prepare($sql);
    $result->bindParam(":id",$id);
    $result->bindParam(":name",$name);
    
    try
    {
        $result->execute();
        echo json_encode(array("message"=>"Data updated"));
        exit;
    }
    catch(Exception $e)
    {
        echo json_encode(array("message"=>"Error to Update"));
        exit;
    }

    

}
//update data end

//delete data start
if($_SERVER['REQUEST_METHOD']=="DELETE")
{

    $id=$_GET['id'];

    $sql="delete from react_user where id=:id";
    $result=$con->prepare($sql);
    $result->bindParam(":id",$id);
    
    try
    {
        $result->execute();
        echo json_encode(array("message"=>"Data deleted"));
        exit;
    }
    catch(Exception $e)
    {
        echo json_encode(array("message"=>"Error to Delete"));
        exit;
    }

    

}
//delete data end

?>